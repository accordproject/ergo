Name of the person to greet: {{name}}.
Thank you!
{{#clause clause1}} Here is a first name: {{name}} {{/clause}}
{{#clause clause2}} Here is a second name: {{name}} {{/clause}}
